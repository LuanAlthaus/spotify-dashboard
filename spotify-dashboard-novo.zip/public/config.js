// Dados pessoais do painel. Este arquivo NÃO vai para o GitHub (está no .gitignore).
const CONFIG = {
  displayName: 'khy4n_rezz',   // Nome mostrado no topo
  cityName: 'Encarnación',     // Cidade mostrada abaixo da temperatura
  latitude: -27.33,            // Latitude da cidade (para a previsão do tempo)
  longitude: -55.87,           // Longitude da cidade
};
